/* ============================================================
   PLATE COMPONENT STYLES
   Extracting exact styles from original source
============================================================ */
.plate-stage{display:flex;flex-direction:column;align-items:center;gap:18px;}
.plate-row{display:flex;flex-wrap:wrap;justify-content:center;align-items:flex-end;gap:24px;}
.plate-item{display:flex;flex-direction:column;align-items:center;gap:8px;}
.plate-item.hidden{display:none;}
.plate-tag{font-family:'IBM Plex Mono',monospace;font-size:0.68rem;letter-spacing:0.18em;text-transform:uppercase;color:var(--mist);display:none;}
.plate-row.show-tags .plate-tag{display:block;}

.plate{
  position:relative;background:#ffffff;border-radius:8px;border:3px solid #161616;
  display:flex;align-items:stretch;
  box-shadow:0 1px 0 rgba(0,0,0,0.04),0 14px 30px -16px rgba(0,0,0,0.4);
  transition:background 0.25s,width 0.3s,height 0.3s;overflow:hidden;
}
.plate.commercial{background:var(--yellow);}
.plate.car,.plate.commercial-car,.plate.commercial-truck{width:400px;height:90px;}
.plate.bike{width:260px;height:82px;}
.plate.bike-square{width:200px;height:172px;}

.plate-left{
  flex-shrink:0;width:46px;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:6px;padding:6px 0;
}
.ashok-chakra{
  width:26px;height:26px;display:block;
  background:radial-gradient(circle at 35% 30%,#ddeeff,#a8c9f0 55%,#e8f0fb 100%);
  border-radius:50%;box-shadow:0 0 0 1px rgba(30,77,156,0.25);
}
.ind-label{font-family:'Oswald',sans-serif;font-weight:700;font-size:0.62rem;letter-spacing:0.12em;color:var(--blue);}

.plate-number{
  flex:1;display:flex;align-items:center;justify-content:center;
  font-family:'Noto Sans Condensed','Oswald',sans-serif;font-weight:900;
  letter-spacing:0.08em;color:#1c1c1c;text-transform:uppercase;word-break:break-all;padding:0 14px;
  text-shadow:1px 1.5px 0 rgba(0,0,0,0.22),2px 3px 4px rgba(0,0,0,0.18);
  transition:font-size 0.2s, opacity 0.4s ease;
}

.plate-number-stack{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:0 8px; transition: opacity 0.4s ease;}
.plate-line{
  font-family:'Noto Sans Condensed','Oswald',sans-serif;font-weight:900;
  letter-spacing:0.04em;color:#1c1c1c;text-transform:uppercase;font-size:1.7rem;line-height:1.2;
  text-shadow:1px 1.5px 0 rgba(0,0,0,0.22),2px 3px 4px rgba(0,0,0,0.18);
}
.plate-caption{font-family:'IBM Plex Mono',monospace;font-size:0.75rem;color:var(--mist);text-align:center;}

/* mini plate preview */
.mini-plate-wrap{display:flex;flex-direction:column;align-items:center;gap:5px;flex-shrink:0;}
.mini-plate{
  background:#fff;border:2px solid #161616;border-radius:5px;
  display:flex;align-items:stretch;overflow:hidden;
  box-shadow:0 4px 10px -4px rgba(0,0,0,0.28);
}
.mini-plate.commercial{background:var(--yellow);}
.mini-left{
  width:24px;display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:3px;padding:3px 0;
}
.mini-chakra{
  width:12px;height:12px;border-radius:50%;
  background:radial-gradient(circle at 35% 30%,#ddeeff,#a8c9f0 55%,#e8f0fb 100%);
}
.mini-ind{font-family:'Oswald',sans-serif;font-weight:700;font-size:0.38rem;letter-spacing:0.1em;color:var(--blue);}
.mini-num{
  font-family:'Noto Sans Condensed','Oswald',sans-serif;font-weight:900;
  font-size:1rem;letter-spacing:0.06em;color:#1c1c1c;padding:0 8px;
  display:flex;align-items:center;
  text-shadow:1px 1px 0 rgba(0,0,0,0.2);
}
.mini-label{font-family:'IBM Plex Mono',monospace;font-size:0.62rem;color:var(--mist);}

/* bike mini plates */
.mini-plates-row{display:flex;align-items:flex-end;gap:10px;justify-content:center;}
.mini-plate-item{display:flex;flex-direction:column;align-items:center;gap:4px;}
.mini-plate-item.hidden{display:none;}
.mini-tag{font-family:'IBM Plex Mono',monospace;font-size:0.58rem;letter-spacing:0.14em;text-transform:uppercase;color:var(--mist);}
.mini-plate.bike-front{width:140px;height:38px;}
.mini-plate.bike-front .mini-num{font-size:0.82rem;}
.mini-plate.bike-back{width:84px;height:84px;flex-direction:column;}
.mini-plate.bike-back .mini-left{width:100%;height:28px;flex-direction:row;justify-content:flex-start;padding:0 5px;gap:4px;border-right:none;border-bottom:none;}
.mini-plate.bike-back .mini-num{flex-direction:column;align-items:center;justify-content:center;font-size:0.82rem;letter-spacing:0.04em;line-height:1.2;text-align:center;}
