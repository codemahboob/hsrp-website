document.getElementById('payNowBtn').addEventListener('click', () => {
  const name   = document.getElementById('addrName').value.trim();
  const phone  = document.getElementById('addrPhone').value.trim();
  const street = document.getElementById('addrStreet').value.trim();
  const city   = document.getElementById('addrCity').value.trim();
  const pin    = document.getElementById('addrPin').value.trim();
  const stateV = document.getElementById('addrState').value;

  if(!name||!phone||!street||!city||!pin||!stateV){
    alert('Please fill all required fields before proceeding.'); return;
  }
  if(phone.length!==10||isNaN(phone)){ alert('Enter a valid 10-digit phone number.'); return; }
  if(pin.length!==6||isNaN(pin)){ alert('Enter a valid 6-digit pincode.'); return; }

  const amountRupees = parseInt(payNowBtn.dataset.amount);
  const labelText    = payNowBtn.dataset.label;
  const vehicleKey   = activeVehicleKey();

  const options = {
    key: "rzp_live_T8Hf8OyhfWilCb",
    amount: amountRupees * 100,
    currency: "INR",
    name: "BharatPlate HSRP",
    description: `${labelText} — ${state.text} (${state.side})`,
    prefill: { name, contact: phone },
    theme: { color: "#1e4d9c" },
    handler: function(response){
       const payment_id = response.razorpay_payment_id || "demo_pay_id";
       window.location.href = `success.html?payment_id=${payment_id}&plate=${encodeURIComponent(state.text)}&vehicle=${vehicleKey}&amount=${amountRupees}&side=${state.side}`;
    },
    modal: {
      ondismiss: function() {
        window.location.href = `cancelled.html?plate=${encodeURIComponent(state.text)}&vehicle=${vehicleKey}&amount=${amountRupees}&side=${state.side}`;
      }
    }
  };

  if(window.Razorpay){
    const rzp = new Razorpay(options);
    rzp.on('payment.failed', function (response){
        window.location.href = `failed.html?payment_id=${response.error.metadata.payment_id}&reason=${encodeURIComponent(response.error.description)}&plate=${encodeURIComponent(state.text)}&vehicle=${vehicleKey}&amount=${amountRupees}&side=${state.side}`;
    });
    rzp.open();
  } else {
    // Fallback for demo without razorpay injected properly
    window.location.href = `success.html?payment_id=pay_demo_success&plate=${encodeURIComponent(state.text)}&vehicle=${vehicleKey}&amount=${amountRupees}&side=${state.side}`;
  }
});
