document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    
    const paymentId = urlParams.get('payment_id') || 'N/A';
    const plate = urlParams.get('plate') || 'XXXX';
    const vehicle = urlParams.get('vehicle') || 'car';
    const amount = urlParams.get('amount') || '0';
    const side = urlParams.get('side') || 'both';

    // Populate data
    document.querySelectorAll('.val-payment').forEach(el => el.textContent = paymentId);
    document.querySelectorAll('.val-amount').forEach(el => el.textContent = '₹' + amount);
    document.querySelectorAll('.val-date').forEach(el => el.textContent = new Date().toLocaleDateString());
    
    let vType = vehicle.includes('commercial') ? 'Commercial' : (vehicle === 'bike' ? 'Bike' : 'Car');
    document.querySelectorAll('.val-vehicle').forEach(el => el.textContent = vType);
    
    let sType = side === 'both' ? 'Front + Back' : (side === 'front' ? 'Front' : 'Back');
    document.querySelectorAll('.val-side').forEach(el => el.textContent = sType);

    // Render Preview
    if(typeof HSRPPlate !== 'undefined') {
        HSRPPlate.render({
            container: '#statusPlatePreview',
            plateNumber: plate,
            vehicle: vehicle,
            side: side,
            isMini: false
        });
    }

    // Play Chime (Web Audio API)
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const playChime = () => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
            osc.frequency.exponentialRampToValueAtTime(1108.73, audioCtx.currentTime + 0.1); // C#6
            
            gain.gain.setValueAtTime(0, audioCtx.currentTime);
            gain.gain.linearRampToValueAtTime(0.5, audioCtx.currentTime + 0.05);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);
            
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 1.5);
        };
        // Browser policy might block audio without interaction, but attempt on load
        playChime();
    } catch(e) { console.log('Audio omitted', e); }

    const copyBtn = document.getElementById('copyBtn');
    if(copyBtn) {
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(paymentId);
            copyBtn.textContent = "Copied!";
            setTimeout(() => copyBtn.textContent = "Copy", 2000);
        });
    }
});
