const PRICING = {
  car:               { label:"Car HSRP",               unit:650, single:350 },
  bike:              { label:"Bike HSRP",               unit:450, single:1 },
  "commercial-truck":{ label:"Commercial (Truck) HSRP", unit:750, single:400 },
  "commercial-car":  { label:"Commercial (Taxi) HSRP",  unit:700, single:380 }
};

let state = { vehicle:"car", commercialSub:"commercial-truck", side:"both", text:"" };

const plateCaption  = document.getElementById('plateCaption');
const plateInput    = document.getElementById('plateInput');
const vehicleTabs   = document.querySelectorAll('#vehicleTabs .seg');
const subTabs       = document.querySelectorAll('#commercialSubTabs .seg');
const commercialSubTabs = document.getElementById('commercialSubTabs');
const sideOpts      = document.querySelectorAll('#sideOptions .seg');
const termsCheck    = document.getElementById('termsCheck');
const bookBtn       = document.getElementById('bookBtn');

// Modal refs
const modalOverlay  = document.getElementById('modalOverlay');
const modalClose    = document.getElementById('modalClose');
const payNowBtn     = document.getElementById('payNowBtn');

function activeVehicleKey(){
  return state.vehicle === "commercial" ? state.commercialSub : state.vehicle;
}

function updateUI(){
  const key    = activeVehicleKey();
  const cfg    = PRICING[key];
  const isDemo = state.text.trim() === "";
  const displayVal = isDemo ? currentCyclePlate : state.text;

  // Render Main Plate
  HSRPPlate.render({
    container: '#plateRow',
    plateNumber: displayVal,
    vehicle: key,
    side: state.side,
    isMini: false
  });

  const colorLabel = key.startsWith("commercial") ? "Yellow base" : "White base";
  const sideLabel  = state.side==="both" ? "Front + Back" : state.side==="front" ? "Front" : "Back";
  plateCaption.textContent = `${cfg.label.replace(' HSRP','')} · ${sideLabel} · ${colorLabel}`;

  const isBoth     = state.side === "both";
  const unitPrice  = isBoth ? cfg.unit : cfg.single;

  document.getElementById('sumVehicle').textContent    = cfg.label;
  document.getElementById('sumUnitPrice').textContent  = `₹${unitPrice}`;
  document.getElementById('sumConfig').textContent     = isBoth ? "Front + Back · 1 set" : `${sideLabel} · 1 plate`;
  document.getElementById('sumTotal').textContent      = `₹${unitPrice}`;

  bookBtn.disabled = !(termsCheck.checked && state.text.trim().length >= 1);
}

vehicleTabs.forEach(tab=>{
  tab.addEventListener('click',()=>{
    vehicleTabs.forEach(t=>t.classList.remove('active'));
    tab.classList.add('active');
    state.vehicle = tab.dataset.type;
    commercialSubTabs.classList.toggle('visible', state.vehicle==="commercial");
    updateUI();
  });
});

subTabs.forEach(st=>{
  st.addEventListener('click',()=>{
    subTabs.forEach(t=>t.classList.remove('active'));
    st.classList.add('active');
    state.commercialSub = st.dataset.sub;
    updateUI();
  });
});

plateInput.addEventListener('input',e=>{
  const val = e.target.value.toUpperCase().replace(/[^A-Z0-9\- ]/g,'');
  e.target.value = val;
  state.text = val;
  updateUI();
});

sideOpts.forEach(opt=>{
  opt.addEventListener('click',()=>{
    sideOpts.forEach(o=>o.classList.remove('active'));
    opt.classList.add('active');
    state.side = opt.dataset.side;
    updateUI();
  });
});

termsCheck.addEventListener('change', updateUI);

// Modal Logic
bookBtn.addEventListener('click',()=>{
  const key   = activeVehicleKey();
  const cfg   = PRICING[key];
  const isBoth = state.side==="both";
  const price = isBoth ? cfg.unit : cfg.single;
  const sideLabel = state.side==="both" ? "Front + Back" : state.side==="front" ? "Front" : "Back";
  const colorLabel = key.startsWith("commercial") ? "Yellow base (commercial)" : "White base (private)";

  HSRPPlate.render({
    container: '#miniPlateWrap',
    plateNumber: state.text || "ENTER NUMBER",
    vehicle: key,
    side: state.side,
    isMini: true,
    hideTags: state.side !== 'both'
  });

  document.getElementById('miniLabel').textContent = `${cfg.label.replace(' HSRP','')} · ${sideLabel}`;
  document.getElementById('modalPlateHeading').textContent = `${cfg.label} — ${state.text}`;
  document.getElementById('modalPlateSub').textContent = `${sideLabel} · ${colorLabel}`;

  document.getElementById('msSumVehicle').textContent = cfg.label;
  document.getElementById('msSumPrice').textContent   = `₹${price}`;
  document.getElementById('msSumConfig').textContent  = isBoth ? "Front + Back · 1 set" : `${sideLabel} · 1 plate`;
  document.getElementById('msSumTotal').textContent   = `₹${price}`;
  document.getElementById('payNowAmount').textContent = `₹${price}`;

  payNowBtn.dataset.amount = price;
  payNowBtn.dataset.label  = cfg.label;

  modalOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
});

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', e=>{ if(e.target===modalOverlay) closeModal(); });
function closeModal(){
  modalOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

// Demo Cycling
const cyclePlates = ["JAAT 0001", "DL01AA0001", "KRISHNA", "MH04H0008", "AMIT X 23"];
let cycleIndex = 0;
let currentCyclePlate = cyclePlates[0];

function cycleDemoPlate(){
  if(state.text.trim() !== "") return; 
  const input = document.getElementById('plateInput');
  input.style.transition = "opacity 0.4s";
  input.style.opacity = "0";
  
  const row = document.getElementById('plateRow');
  row.style.transition = "opacity 0.4s";
  row.style.opacity = "0";

  setTimeout(()=>{
    cycleIndex = (cycleIndex + 1) % cyclePlates.length;
    currentCyclePlate = cyclePlates[cycleIndex];
    input.placeholder = currentCyclePlate;
    updateUI();
    input.style.opacity = "1";
    row.style.opacity = "1";
  }, 400);
}
setInterval(cycleDemoPlate, 3000);
updateUI();
